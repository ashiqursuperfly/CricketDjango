create procedure init_teams()
    language plpgsql
as
$$
BEGIN
    CREATE TEMP TABLE tmp_table ON COMMIT DROP AS SELECT * FROM TEAMS WITH NO DATA;
    copy tmp_table FROM 'E:/Pycharm Workspace/EspnCricinfo/api_data/teams.csv' DELIMITER ',' CSV HEADER;
    INSERT INTO TEAMS SELECT DISTINCT ON (team_id) * FROM tmp_table ON CONFLICT DO NOTHING;
    COMMIT;
END;
$$;

alter procedure init_teams() owner to ashiq;

