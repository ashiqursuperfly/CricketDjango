create procedure init_players_plays_for_teams()
    language plpgsql
as
$$
BEGIN
    CREATE TEMP TABLE tmp_table ON COMMIT DROP AS SELECT * FROM PLAYER_PLAYS_FOR_TEAMS WITH NO DATA;
    copy tmp_table FROM 'E:/Pycharm Workspace/EspnCricinfo/api_data/player_plays_for_teams.csv' DELIMITER ',' CSV HEADER;
    INSERT INTO PLAYER_PLAYS_FOR_TEAMS SELECT DISTINCT ON (player_id,team_id) * FROM tmp_table ON CONFLICT DO NOTHING;
    COMMIT;
END;
$$;

alter procedure init_players_plays_for_teams() owner to ashiq;

