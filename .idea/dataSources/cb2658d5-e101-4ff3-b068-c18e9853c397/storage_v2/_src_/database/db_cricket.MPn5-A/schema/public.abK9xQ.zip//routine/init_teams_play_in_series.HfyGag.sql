create procedure init_teams_play_in_series()
    language plpgsql
as
$$
BEGIN
    CREATE TEMP TABLE tmp_table ON COMMIT DROP AS SELECT * FROM TEAMS_PLAYS_IN_SERIES WITH NO DATA;
    copy tmp_table FROM 'E:/Pycharm Workspace/EspnCricinfo/api_data/teams_plays_in_series.csv' DELIMITER ',' CSV HEADER;
    INSERT INTO TEAMS_PLAYS_IN_SERIES SELECT DISTINCT ON (series_id,team_id) * FROM tmp_table ON CONFLICT DO NOTHING;
    COMMIT;
END;
$$;

alter procedure init_teams_play_in_series() owner to ashiq;

