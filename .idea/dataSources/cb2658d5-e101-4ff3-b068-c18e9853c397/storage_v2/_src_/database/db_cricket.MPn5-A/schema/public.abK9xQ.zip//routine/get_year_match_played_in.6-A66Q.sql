create function get_year_match_played_in(integer) returns integer
    language plpgsql
as
$$
DECLARE id INTEGER; year integer;
begin
   id = $1;

 select extract(year from start_date) into year from match where match_id = id;
 return year ;
END;
$$;

alter function get_year_match_played_in(integer) owner to ashiq;

