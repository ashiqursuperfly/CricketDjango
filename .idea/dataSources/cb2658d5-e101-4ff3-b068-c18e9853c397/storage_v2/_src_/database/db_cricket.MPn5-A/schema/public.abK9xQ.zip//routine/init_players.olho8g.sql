create procedure init_players()
    language plpgsql
as
$$
DECLARE R RECORD;
BEGIN
    CREATE TEMP TABLE tmp_table ON COMMIT DROP AS SELECT * FROM PLAYERS WITH NO DATA;
    copy tmp_table FROM 'E:/Pycharm Workspace/EspnCricinfo/api_data/players.csv' DELIMITER ',' CSV HEADER;
    FOR R IN (SELECT * FROM tmp_table) LOOP
    IF R.player_id IN (SELECT player_id FROM players) THEN
      UPDATE players SET nationality = R.nationality WHERE player_id = R.player_id;
    ELSE INSERT INTO players VALUES(R.player_id,R.full_name,R.nationality,R.batting_style,R.bowling_style,R.speciality);
    END IF ;
    END LOOP;
    COMMIT;
END;
$$;

alter procedure init_players() owner to ashiq;

