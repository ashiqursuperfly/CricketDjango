create procedure initialize_match(integer, character varying, integer, integer, integer, integer, character varying, character varying, date, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer)
    language plpgsql
as
$$
DECLARE u_id INTEGER; f_name VARCHAR(100); nation VARCHAR(100);
BEGIN

  insert into match (match_id, match_type, team1_id, team2_id, captain1, captain2, venue, stadium_name, start_date, series_id)  values  ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) on conflict do nothing;

  insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $11 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $11) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $12 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $12) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $13 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $13) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $14 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $14) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $15 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $15) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $16 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $16) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $17 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $17) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $18 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $18) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $19 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $19) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $20 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $20) on conflict do nothing ;

   insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 1, $3, $21 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($3, $21) on conflict do nothing ;

  insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $22 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $22) on conflict do nothing ;



    insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $23 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $23) on conflict do nothing ;


    insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $24 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $24) on conflict do nothing ;


    insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $25 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $25) on conflict do nothing ;


    insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $26 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $26) on conflict do nothing ;


    insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $27 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $27) on conflict do nothing ;


    insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $28 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $28) on conflict do nothing ;


    insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $29 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $29) on conflict do nothing ;


    insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $30 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $30) on conflict do nothing ;


    insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $31 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $31) on conflict do nothing ;

  insert into match_performance_data (match_id, innings_no, team_id, player_id) values ($1, 2, $4, $32 ) on conflict do nothing;

  insert into player_plays_for_teams (team_id, player_id) VALUES ($4, $32) on conflict do nothing ;

  insert into umpires (player_id)  values ($33) on conflict do nothing;
  insert into umpires_conducts_match (match_id, player_id, umpiring_role)  values ($1, $33, 'umpire1');

  insert into umpires (player_id)  values ($34) on conflict do nothing;
  insert into umpires_conducts_match (match_id, player_id, umpiring_role)  values ($1, $34, 'umpire2');

  insert into umpires (player_id)  values ($35) on conflict do nothing;
  insert into umpires_conducts_match (match_id, player_id, umpiring_role)  values ($1, $35, 'umpire3');

END;
$$;

alter procedure initialize_match(integer, varchar, integer, integer, integer, integer, varchar, varchar, date, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer) owner to ashiq;

