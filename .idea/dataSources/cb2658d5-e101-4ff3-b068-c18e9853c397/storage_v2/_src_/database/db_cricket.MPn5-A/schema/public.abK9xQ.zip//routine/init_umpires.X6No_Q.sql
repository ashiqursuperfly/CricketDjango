create procedure init_umpires()
    language plpgsql
as
$$
DECLARE R RECORD;
BEGIN
    CREATE TEMP TABLE tmp_table
    (
      umpire_id INTEGER,
      full_name VARCHAR(100),
      nationality VARCHAR(100)
    ) ON COMMIT DROP ;
    copy tmp_table FROM 'E:/Pycharm Workspace/EspnCricinfo/api_data/umpires.csv' DELIMITER ',' CSV HEADER;
    FOR R in (SELECT * FROM tmp_table) LOOP
      CALL validate_umpire_fk(R.umpire_id,R.full_name,R.nationality);
    END LOOP;
    COMMIT;
END;
$$;

alter procedure init_umpires() owner to ashiq;

