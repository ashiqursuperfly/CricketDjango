create function update_team_rankings() returns trigger
    language plpgsql
as
$$
DECLARE R INTEGER; t_id INTEGER;_type VARCHAR(100);
  BEGIN
  t_id := New.winner;
  _type := New.match_type;
  IF t_id IS NULL THEN
    return new;
  end if;
  raise notice 'points updated for team %',t_id;
  R := (SELECT team_id From team_ranking where match_format = _type and team_id = t_id);
  IF R is NULL THEN
    INSERT INTO team_ranking VALUES (t_id,_type,5);
  else 
    UPDATE team_ranking SET points = points + 5 where match_format = _type;
  end if;
  RETURN NEW;
  END;
$$;

alter function update_team_rankings() owner to ashiq;

