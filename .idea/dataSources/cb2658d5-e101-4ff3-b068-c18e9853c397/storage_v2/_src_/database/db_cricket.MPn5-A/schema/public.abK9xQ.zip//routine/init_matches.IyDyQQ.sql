create procedure init_matches()
    language plpgsql
as
$$
BEGIN
    CREATE TEMP TABLE tmp_table ON COMMIT DROP AS SELECT * FROM MATCH WITH NO DATA;
    copy tmp_table FROM 'E:/Pycharm Workspace/EspnCricinfo/api_data/match.csv' DELIMITER ',' CSV HEADER;
    INSERT INTO MATCH SELECT DISTINCT ON (match_id) * FROM tmp_table ON CONFLICT DO NOTHING;
    COMMIT;
END;
$$;

alter procedure init_matches() owner to ashiq;

