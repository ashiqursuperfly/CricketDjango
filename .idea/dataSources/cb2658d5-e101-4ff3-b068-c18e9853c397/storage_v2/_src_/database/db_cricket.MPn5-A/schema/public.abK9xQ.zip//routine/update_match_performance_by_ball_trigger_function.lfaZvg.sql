create function update_match_performance_by_ball_trigger_function() returns trigger
    language plpgsql
as
$$
DECLARE
  overs      varchar(200) ;
  ovr_int    integer;
  ovr_frac   integer;
  is_B_wkt   INTEGER;
  bowl_inn_no INTEGER;
  isNb       integer ;
  isWide     integer ;
  ball_count double precision ;
  is4        INTEGER; is6 INTEGER; isWkt INTEGER; out_condition VARCHAR(200); curr_overs_bowled DOUBLE PRECISION;
BEGIN
   is_B_wkt := 0;
   IF NEW.run_scored = 4 THEN
     is4 := 1;
   else
     is4 := 0;
   end if;
   IF NEW.run_scored = 6 THEN
     is6 := 1;
   else
     is6 := 0;
   end if;

   if NEW.wicket_type is not null then
     isWkt := 1;
     is_B_wkt := 1;
     out_condition := new.wicket_type || ' b ' || (select full_name from players where player_id = new.baller_id);
     if lower(new.wicket_type) LIKE '%catch%' then
       out_condition := out_condition || ' c ' || (select full_name from players where player_id = new.wicket_taking_fielder_id);
     elsif lower(new.wicket_type) LIKE '%run%' then
       out_condition := out_condition || 'run out ' || (select full_name from players where player_id = new.wicket_taking_fielder_id);
       is_B_wkt := 0;
     end if;
   else
     isWkt := 0;
   end if;
   raise notice 'out condition %',out_condition;
   UPDATE match_performance_data set runs_scored = runs_scored + NEW.run_scored , balls_batted = balls_batted + 1 ,fours_scored = fours_scored + is4, sixes_scored = sixes_scored + is6, final_out_condition = out_condition
   where match_id = NEW.match_id and player_id = NEW.batsman_id and innings_no = NEW.innings_no ;

   if new.innings_no = 1 then
     bowl_inn_no := 2;
   else
     bowl_inn_no := 1;
   end if;
   curr_overs_bowled := (SELECT overs_bowled FROM match_performance_data where player_id = new.baller_id and match_id = new.match_id and innings_no = bowl_inn_no);


   raise notice 'curr_overs_bowled %',curr_overs_bowled;
   if lower(new.balling_violation_type) = 'wide' then
   ball_count := 0;
   isWide := 1;
   elsif lower(new.balling_violation_type) = 'nb' then
   ball_count := 0;
   isNb := 1;
   else
     ball_count := 0.1;
     curr_overs_bowled := curr_overs_bowled + ball_count;
     raise notice 'current overs %',curr_overs_bowled;
     ovr_frac := (SELECT to_number(split_part(to_char(curr_overs_bowled,'999.9'), '.', 2),'9'));
     ovr_int := (SELECT to_number(split_part(to_char(curr_overs_bowled,'0999.9'), '.', 1),'09999'));
     if (ovr_frac) >= 6 then
      ovr_frac := 0;
      ovr_int := ovr_int + 1;
     end if;
     raise notice 'ovr_int % ovr_frac%',ovr_int,ovr_frac;
   end if;
   overs := ovr_int || '.' || ovr_frac;
   raise notice 'updated overs %',to_number(overs,'09999.9');
   update match_performance_data set wickets_taken = wickets_taken + is_B_wkt,runs_conceded = runs_conceded + new.run_scored,
                                     no_balls = no_balls + isNb, wides = wides + isWide, overs_bowled = to_number(overs,'09999.9')
    where match_id = new.match_id and innings_no = bowl_inn_no and player_id = new.baller_id;

    return new;
END;
$$;

alter function update_match_performance_by_ball_trigger_function() owner to ashiq;

