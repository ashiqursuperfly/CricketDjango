create function update_no_of_matches_umpired_trigger_function() returns trigger
    language plpgsql
as
$$
DECLARE R VARCHAR(50); 
BEGIN
 R := (SELECT match_type FROM match WHERE match_id = NEW.match_id); 
 raise notice 'update_no_of_matches_umpired_trigger_function called';
 IF  R = 'T20' THEN
   UPDATE umpires SET t20s_umpired = t20s_umpired + 1 WHERE NEW.player_id = umpires.player_id;
   raise notice 'Match Count Updated For an umpire %',new.player_id;
 ELSIF  R = 'ODI' THEN
   UPDATE umpires SET odis_umpired = odis_umpired + 1 WHERE NEW.player_id = umpires.player_id;
   raise notice 'Match Count Updated For an umpire %',new.player_id;
 ELSIF  R = 'TEST' THEN
   UPDATE umpires SET tests_umpired = tests_umpired + 1 WHERE NEW.player_id = umpires.player_id;
   raise notice 'Match Count Updated For an umpire %',new.player_id;
 end if;
 RETURN NEW;
END;
$$;

alter function update_no_of_matches_umpired_trigger_function() owner to ashiq;

