create function get_player_name(integer) returns character varying
    language plpgsql
as
$$
DECLARE id INTEGER; name VARCHAR(100);
begin 
    id = $1;
  
  select full_name into name from players where player_id = id;
  return name ; 
END;
$$;

alter function get_player_name(integer) owner to ashiq;

