create function update_player_rankings() returns trigger
    language plpgsql
as
$$
DECLARE R RECORD; p_id INTEGER; m_id INTEGER; _type VARCHAR(100); spec VARCHAR(200);
  BEGIN
    p_id := NEW.player_id;
    m_id := NEW.match_id;
    _type := (SELECT match_type FROM match WHERE match_id = m_id);
    spec := (SELECT speciality FROM players WHERE player_id = p_id);

    if p_id NOT IN (SELECT distinct player_id FROM player_ranking) THEN
      If Lower(spec) LIKE '%bat%' THEN
          INSERT INTO player_ranking VALUES (p_id,_type,'Batting',NEW.runs_scored*10);
          --RAISE notice 'Player Ranking Inserted for player: % criteria: Batting format: %',p_id,_type;
      end if;
      If Lower(spec) LIKE '%bowl%' THEN
          INSERT INTO player_ranking VALUES (p_id,_type,'Bowling', NEW.wickets_taken * 100 - NEW.runs_conceded);
          --RAISE notice 'Player Ranking Inserted for player: % criteria: Bowling format: %',p_id,_type;
      end if;
      If Lower(spec) LIKE '%all%' THEN
          INSERT INTO player_ranking VALUES (p_id,_type,'All-Rounder',NEW.runs_scored*10 + NEW.wickets_taken * 100 - NEW.runs_conceded);
         --RAISE notice 'Player Ranking Inserted for player: % criteria: Allrounder format: %',p_id,_type;
      end if;
    else
      For R IN (SELECT * from player_ranking where player_id = p_id) LOOP
        If Lower(R.criteria) LIKE '%bat%' THEN
          UPDATE player_ranking SET points = R.points + NEW.runs_scored*10 where player_id = p_id And criteria = R.criteria;
        elsif Lower(R.criteria) LIKE '%bowl%' THEN
          UPDATE player_ranking SET points = R.points + NEW.wickets_taken * 100 - NEW.runs_conceded
          where player_id = p_id And criteria = R.criteria;
        else
          UPDATE player_ranking SET points = NEW.runs_scored*10 + NEW.wickets_taken * 100 - NEW.runs_conceded
          where player_id = p_id And criteria = R.criteria;
        end if;
        --RAISE notice 'Player Ranking updated for player % with criteria % format %',p_id,R.criteria,R.match_format;
      end loop;
    end if;
 RETURN NEW;
END;
$$;

alter function update_player_rankings() owner to ashiq;

