create procedure destroy_db()
    language plpgsql
as
$$
BEGIN
drop trigger update_team_ranking_trigger on match;
drop trigger update_rankings_trigger on match_performance_data;
drop trigger update_matches_umpired ON umpires_conducts_match;
drop procedure init_teams();
drop procedure init_players();
drop procedure init_players_plays_for_teams();
drop procedure init_series();
drop procedure init_teams_play_in_series();
drop procedure init_umpires();
drop procedure validate_umpire_fk(integer, varchar, varchar);
drop procedure init_umpire_conducts_match();
drop procedure init_matches();
drop procedure init_all_match_data();
drop procedure destroy_db();
drop function update_no_of_matches_umpired_trigger_function();
drop function update_team_rankings();
drop function update_player_rankings();
DROP TABLE match_performance_data;
DROP TABLE Umpires_Conducts_Match;
DROP TABLE MATCH;
DROP TABLE COACHES;
DROP TABLE UMPIRES;
DROP TABLE PLAYER_PLAYS_FOR_TEAMS;
DROP TABLE PLAYER_RANKING;
DROP TABLE TEAM_RANKING;
DROP TABLE TEAMS_PLAYS_IN_SERIES;
DROP TABLE SERIES;
DROP TABLE PLAYERS;
DROP TABLE TEAMS;

COMMIT;
END;
$$;

alter procedure destroy_db() owner to ashiq;

