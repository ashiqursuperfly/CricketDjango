create procedure validate_umpire_fk(integer, character varying, character varying)
    language plpgsql
as
$$
DECLARE u_id INTEGER; f_name VARCHAR(100); nation VARCHAR(100);
BEGIN
    u_id = $1; f_name = $2; nation = $3;
    INSERT INTO PLAYERS(player_id, full_name, nationality) VALUES(u_id,f_name,nation) ON CONFLICT DO NOTHING ;
    INSERT INTO UMPIRES(player_id) VALUES(u_id) ON CONFLICT DO NOTHING;
    COMMIT;
END;
$$;

alter procedure validate_umpire_fk(integer, varchar, varchar) owner to ashiq;

