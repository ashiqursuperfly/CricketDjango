create procedure init_series()
    language plpgsql
as
$$
DECLARE R RECORD;
BEGIN
    CREATE TEMP TABLE tmp_table ON COMMIT DROP AS SELECT * FROM SERIES WITH NO DATA;
    copy tmp_table FROM 'E:/Pycharm Workspace/EspnCricinfo/api_data/series.csv' DELIMITER ',' CSV HEADER;
    FOR R IN (SELECT * FROM tmp_table) LOOP
    IF R.series_id IN (SELECT series_id FROM series) THEN
      UPDATE series SET mots = R.mots,winner = R.winner WHERE series_id = R.series_id;
    ELSE INSERT INTO SERIES VALUES(R.series_id,R.series_name,R.mots,R.winner);
    END IF ;
    END LOOP;
COMMIT;
END;
$$;

alter procedure init_series() owner to ashiq;

