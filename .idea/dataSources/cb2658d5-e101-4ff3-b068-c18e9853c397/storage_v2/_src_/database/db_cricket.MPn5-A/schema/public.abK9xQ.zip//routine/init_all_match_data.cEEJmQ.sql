create procedure init_all_match_data()
    language plpgsql
as
$$
BEGIN

call init_teams();
call init_players();
call init_players_plays_for_teams();
call init_series();
call init_teams_play_in_series();
call init_umpires();
call init_matches();
call init_umpire_conducts_match();
    COMMIT;
END;
$$;

alter procedure init_all_match_data() owner to ashiq;

