create procedure init_umpire_conducts_match()
    language plpgsql
as
$$
BEGIN
    CREATE TEMP TABLE tmp_table ON COMMIT DROP AS SELECT * FROM umpires_conducts_match WITH NO DATA;
    copy tmp_table FROM 'E:/Pycharm Workspace/EspnCricinfo/api_data/umpire_conducts_match.csv' DELIMITER ',' CSV HEADER;
    INSERT INTO umpires_conducts_match SELECT DISTINCT ON (player_id,match_id) * FROM tmp_table ON CONFLICT DO NOTHING;
    COMMIT;
END;
$$;

alter procedure init_umpire_conducts_match() owner to ashiq;

